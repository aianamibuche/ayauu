# Задание 1
salaries = [30000, 40000, 50000, 60000, 70000]
salaries = list(map(lambda x: x * 1.1, salaries))
print(salaries)

# Задание 2
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
even_numbers = list(filter(lambda x: x % 2 == 0, numbers))
print(even_numbers)

# Задание 3
names = ["ron", "wow", "cherry", "michael"]
names = list(filter(lambda x: x[0].islower(), names))
print(names)

# Задание 4
passwords = ["Data123", "securePass123", "helloWorld", "qwerty123"]
valid_passwords = list(filter(lambda x: any(c.isdigit() for c in x) and any(c.isupper() for c in x), passwords))
print(valid_passwords)

# Задание 5
ages = [15, 22, 18, 25, 32, 10, 27]
adults = list(filter(lambda x: x >= 18, ages))
print(adults)

# Задание 6
prices = [150, 200, 230, 120, 500]
discounted_prices = list(filter(lambda x: x >= 300, map(lambda x: x * 0.9, prices)))
print(discounted_prices)

# Задание 7
words = ["apple", "banana", "cherry", "date", "fig", "grape"]
filtered_words = list(filter(lambda x: x.startswith("a") or x.startswith("g"), words))
print(filtered_words)

# Задание 8
students = [
    {"name": "Alice", "grade": 85},
    {"name": "Bob", "grade": 70},
    {"name": "Charlie", "grade": 90},
    {"name": "Diana", "grade": 65}
]
average = sum(map(lambda x: x["grade"], students)) / len(students)
above_average = list(map(lambda x: x["name"], filter(lambda x: x["grade"] > average, students)))
print(above_average)